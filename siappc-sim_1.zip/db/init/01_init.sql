-- Este script solo corre la PRIMERA vez que se crea el volumen de MariaDB.
--
-- Aqui NO se crean las tablas ni las vistas a proposito. Las crea el simulador
-- al arrancar, a partir de la definicion que vive en src/siappc/bd.py y
-- db/vistas.sql. De esa forma el esquema no puede quedar desincronizado del
-- codigo: no hay dos fuentes de verdad que mantener a mano.
--
-- Para ver el DDL de referencia:  docker compose run --rm sim esquema

ALTER DATABASE siappc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Zona horaria en UTC dentro del contenedor: las marcas de tiempo de las
-- corridas quedan comparables aunque el equipo cambie de huso.
SET GLOBAL time_zone = '+00:00';
