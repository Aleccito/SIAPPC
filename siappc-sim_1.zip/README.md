# SIAPPC — simulación en código del flujo de politraumatizados

Modelo de eventos discretos en Python que **replica el Process Flow construido en
FlexSim** para el flujo del paciente politraumatizado con triaje rojo del
Hospital Santo Tomás. No sustituye a FlexSim: es su gemelo de verificación.

Sirve para dos cosas que en FlexSim son caras o imposibles:

1. **Verificación cruzada.** Dos implementaciones independientes de la misma
   lógica. Si dan lo mismo, la lógica está bien implementada. Si no, hay un
   error en alguno de los dos y sabemos dónde buscar.
2. **Barrido de escenarios.** 30 réplicas de 5 escenarios corren en 85 segundos
   y quedan en MariaDB con sus intervalos de confianza. A mano, en FlexSim, eso
   son horas de clics.

---

> **¿Solo quieres usarlo?** Ve a **[`GUIA_DE_USO.md`](GUIA_DE_USO.md)**: el paso
> a paso de qué correr, qué abrir y qué mirar. Este README explica cómo está
> construido por dentro.

## Arranque rápido

```bash
mkdir -p salidas
docker compose up --build
```

(El `.env` es opcional: todas las variables tienen valor por defecto. Cópialo
con `cp .env.example .env` solo si quieres cambiar contraseñas o puertos.)

Eso levanta MariaDB, espera a que esté lista, corre el escenario base y los
cuatro escenarios de `config/escenarios/`, y deja los resultados en la base de
datos. Adminer queda en **http://localhost:8080** (servidor `mariadb`, usuario y
contraseña `siappc`).

El contenedor `sim` termina cuando acaba: es un simulador por lotes, no un
servicio. Que salga con código 0 es lo normal.

Para correr cosas sueltas:

```bash
docker compose run --rm sim correr --config config/base.yaml --replicas 50
docker compose run --rm sim comparar --metrica tiempo_sistema_medio
docker compose run --rm sim parametros --detalle
docker compose run --rm sim verificar
```

### Sin Docker

```bash
pip install -r requirements.txt
PYTHONPATH=src python -m siappc correr --sin-bd     # solo CSV
PYTHONPATH=src python -m pytest                      # las pruebas
```

---

## Qué hay dentro

```
config/base.yaml              todos los parámetros, cada uno con su fuente declarada
config/escenarios/*.yaml      escenarios que heredan del base y solo pisan lo que cambia
src/siappc/modelo.py          el motor: espejo bloque a bloque del Process Flow
src/siappc/kpis.py            indicadores, calculados sobre la bitácora
src/siappc/bd.py              esquema de MariaDB
db/vistas.sql                 vistas de análisis (se recrean en cada corrida)
tests/                        54 pruebas de verificación
salidas/<escenario>/*.csv     los mismos datos, para Excel o R
```

## Cómo se lee un resultado

Todo entra por **`v_resumen_escenario`** (una fila por escenario) y sigue por
**`v_cuellos_botella`** (ranking de zonas por espera). Después:

| Vista | Para qué |
|---|---|
| `v_resumen_escenario` | Los seis números de cabecera de cada escenario |
| `v_cuellos_botella` | Qué zona hace esperar más, con su utilización al lado |
| `v_zonas` | Utilización, cola, espera y pico de ocupación por zona |
| `v_actividades` | Espera y servicio por actividad (separa Rx de FAST) |
| `v_kpi_escenario` | Todo, con media, desviación e intervalo de confianza |
| `v_parametros_fuente` | Cuántos parámetros son datos reales y cuántos supuestos |
| `v_serie_zona` | Ocupación y cola a lo largo del tiempo, para graficar |
| `v_recorrido_paciente` | El recorrido de un paciente concreto, paso a paso |
| `v_utilizacion_sql` | La utilización recalculada en SQL puro, para auditar |

Ejemplo:

```sql
SELECT * FROM v_cuellos_botella WHERE escenario = 'base' ORDER BY puesto;
```

**Cómo se lee `utilizacion_pct` en un servicio de trauma:** alto es malo. Una
sala de reanimación al 90% no es eficiente, es una sala sin reserva para el
siguiente paciente crítico. Esa es la diferencia entre un modelo de fábrica y
uno de urgencias.

---

## Correspondencia con el modelo de FlexSim

| Bloque de FlexSim | Dónde está en el código |
|---|---|
| Fuente Entre llegadas | `llegadas.entre_llegadas` en el YAML |
| Crear objeto + Asignar atributos | `Modelo._llegada_de_pacientes` |
| Demora (sin restricción) | `Modelo._demora` |
| Zona de entrada / Zona de salida | `Modelo._adquirir` / `Modelo._liberar` |
| Zona (capacidad) | `simpy.Resource` con `capacity` |
| Decidir (2 salidas) | `Modelo._decidir` |
| Decidir (3 salidas) | `Modelo._elegir_lesion` |
| Destruir objeto | `Modelo._salir` |
| Mover objeto | *no se implementa*: es representación 3D, no lógica |

Los tiempos se escriben con **la misma sintaxis de FlexSim** (`uniform(3,5)`,
`triangular(20,45,120)`, `exponential(360)`), incluido el argumento de *stream*,
que se acepta y se ignora. Se pueden copiar y pegar entre los dos modelos sin
traducir nada.

---

## De dónde salen los números

Cada parámetro del YAML declara su fuente. `siappc parametros` lo resume:

```
supuesto        22   44.0 %
modelo_actual   16   32.0 %
encuesta         7   14.0 %
estimado         5   10.0 %
dato_real        0    0.0 %
```

**Ningún parámetro es todavía un dato real del hospital.** El modelo sirve para
comparar escenarios entre sí, no para afirmar cuánto tarda de verdad un paciente
en el Santo Tomás. Para eso hacen falta, en orden de importancia:

1. Tasa de llegadas de politraumatizados rojos por día y por hora.
2. Distribución de rutas: qué proporción es estable, cuántos operan, cuántos van
   a UCI.
3. Estancias reales de UCI, hospitalización y rehabilitación.
4. Volumen de pacientes **no traumatizados** que compiten por TAC, quirófano y
   UCI. Sin esto el TAC parece libre casi siempre, que es lo que hoy pasa.

---

## Reproducibilidad

- Cada paciente lleva su propio generador de números aleatorios, derivado de
  `(semilla, número de paciente)`. El paciente 42 de la réplica 3 tiene la misma
  edad, los mismos tiempos y las mismas decisiones **en todos los escenarios**;
  lo único que cambia entre escenarios es la congestión. Es la técnica de
  números aleatorios comunes, y hace que las diferencias se detecten con menos
  réplicas.
- La configuración completa ya resuelta se guarda en la tabla `escenario`, junto
  con su huella `hash_config`. Una corrida se puede repetir sin depender de los
  archivos del disco.
- Misma semilla, mismo resultado, siempre. Hay una prueba que lo comprueba.

---

## Verificación

```bash
PYTHONPATH=src python -m pytest        # 54 pruebas
PYTHONPATH=src python -m siappc verificar
```

Lo que se comprueba:

- Ninguna zona supera nunca su capacidad.
- El paciente estable recorre las cuatro paradas diagnósticas; el inestable pasa
  por exactamente una intervención crítica y no entra a diagnóstico.
- Quien muere en UCI no continúa a hospitalización.
- Más capacidad nunca alarga la cola (prueba de monotonía).
- Se cumple la ley de Little: cola media = espera media × tasa.
- La utilización calculada en Python coincide con la recalculada en SQL puro
  (`v_utilizacion_sql`), hasta el decimal.
- Los resultados no cambian según cuándo pase el recolector de basura de Python
  (esto fue un error real durante el desarrollo, y ahora tiene su propia prueba).

Verificar no es validar. Todo esto comprueba que el modelo hace lo que dijimos
que hace. Que además se parezca al hospital es otra cosa, y necesita datos.
