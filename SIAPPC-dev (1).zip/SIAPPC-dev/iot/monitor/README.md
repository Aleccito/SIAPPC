# Monitor de signos vitales — Raspberry Pi

Monitor de cabecera hecho con **MAX30102** (SpO2 y pulso), **AD8232** (ECG) y
**ADS1115** (conversor A/D). Hace dos cosas:

1. **Muestra** en la pantalla del Pi un monitor de paciente a pantalla completa:
   ECG con papel milimetrado, pletismografia, respiracion, numeros grandes y
   alarmas.
2. **Publica** los signos vitales en JSON por **MQTT sobre TLS** al backend de
   SIAPPC. El contrato esta en [JSON.md](JSON.md).

En pantalla **solo aparece lo que estos tres modulos pueden medir**. Cada caja
del panel numerico lleva escrito de que sensor sale, y lo que es una estimacion
esta rotulado como tal.

Por defecto el monitor mide **en continuo**, como un monitor de cabecera: los
sensores no se apagan y cada tanda de signos vitales sale al broker sola. Es lo
que necesita SIAPPC — el backend abre las alertas a partir de esas lecturas, y
un paciente desatendido tiene que generarlas sin que nadie toque el equipo.

Existe ademas un modo **a demanda** (`--a-demanda`) para tomas puntuales: los
sensores arrancan apagados, se aprieta `X` y se mide una ventana de 10 s. NO es
el modo para una cama de UCI. Ver [Medicion a demanda](#medicion-a-demanda).

![Pantalla del monitor](docs/pantalla-normal.png)

![Con alarma activa](docs/pantalla-alarma.png)

Panel de diagnostico (tecla `D`): la salud del **equipo**, separada de los
signos vitales del paciente.

![Panel de diagnostico](docs/pantalla-diagnostico.png)

> ⚠️ **Esto no es un equipo medico.** No esta certificado ni calibrado contra
> ningun patron. La curva de SpO2 es una aproximacion generica y la deteccion
> de QRS no es de grado diagnostico. Sirve para aprender, prototipar y ver
> tendencias. No lo uses para diagnosticar ni para decidir nada sobre la salud
> de una persona.

---

## Que mide cada modulo (y que no)

| Modulo | Que mide de verdad | Lo que sale en pantalla |
|---|---|---|
| **AD8232** | un canal de ECG analogico + LO+/LO- de electrodo suelto | traza de ECG, **FC**, intervalo R-R, RMSSD de corto plazo |
| **ADS1115** | nada propio: es el conversor A/D del AD8232 | digitaliza el ECG y avisa si la senial satura |
| **MAX30102** | luz roja e infrarroja reflejada | pletismografia, **SpO2**, **PR**, **indice de perfusion** |

**Lo que este equipo no mide**, y por eso no aparece como signo vital:
temperatura corporal, presion arterial, capnografia, y respiracion por
impedancia toracica o por flujo.

Un caso de frontera, marcado en la pantalla en vez de disimulado:

- **RESP** sale de como la respiracion mueve la linea de base del
  pletismografo. **No hay ningun sensor de respiracion en este equipo**: es una
  tecnica real, pero es una **estimacion**, y el numero va con un `~` adelante
  y la caja dice ESTIMADA. Si preferis no mostrarlo, `resp.enabled: false` en la
  configuracion lo saca junto con su carril.
  Como funciona, que la ensucia y que habria que agregar para medirla de verdad:
  **[docs/respiracion.md](docs/respiracion.md)**.

Un par de aclaraciones sobre precision, para que nadie lea de mas:

- Los **mV del ECG** salen de dividir por la ganancia nominal del modulo
  (1100 en el diseno de referencia del AD8232). Es una conversion nominal, no
  una calibracion contra un patron.
- El **SpO2** usa una curva empirica generica. Un oximetro comercial se calibra
  contra co-oximetria en personas reales.
- La traza dice **`ECG`** a secas y no `ECG II`: con 3 electrodos la derivacion
  depende de donde los pegues, y el modulo no tiene forma de saberlo. Si los
  ubicas para derivacion II, poné `ecg.lead_label: "ECG II"` en la config.

---

## Probarlo ya, sin hardware

Anda en Windows, Mac o Linux, con seniales simuladas:

```bash
pip install pygame paho-mqtt
python main.py --demo --windowed
```

En modo demo, las teclas **F1..F6** mueven la senial (bajar SpO2, subir la
frecuencia, sacar el dedo, despegar un electrodo) para ver las alarmas sin
tener que provocarlas de verdad.

---

## Cableado

Todo por I2C, los dos sensores comparten el mismo bus. Las direcciones no
chocan: ADS1115 en `0x48` y MAX30102 en `0x57`.

| Desde | Hasta | Pin fisico del Pi | GPIO |
|---|---|---|---|
| ADS1115 VDD | 3V3 | 1 | — |
| ADS1115 GND | GND | 6 | — |
| ADS1115 SDA | SDA1 | 3 | 2 |
| ADS1115 SCL | SCL1 | 5 | 3 |
| ADS1115 ADDR | GND (→ 0x48) | 6 | — |
| **AD8232 OUTPUT** | **ADS1115 A0** | — | — |
| AD8232 3.3V | 3V3 | 17 | — |
| AD8232 GND | GND | 9 | — |
| AD8232 LO+ | | 15 | 22 |
| AD8232 LO- | | 13 | 27 |
| MAX30102 VIN | 3V3 | 1 | — |
| MAX30102 GND | GND | 6 | — |
| MAX30102 SDA | SDA1 | 3 | 2 |
| MAX30102 SCL | SCL1 | 5 | 3 |
| MAX30102 INT | opcional | 11 | 17 |
| Buzzer **pasivo** (+) | opcional | 32 | 12 |
| Buzzer (−) | GND | 34 | — |

**El pin de cada cosa se puede cambiar** en `config.py` o en un `config.json`.
Si cambias uno, corre el diagnostico (mas abajo): avisa si quedaron dos cosas
asignadas al mismo GPIO, que es el error mas dificil de ver a ojo.

Dos aclaraciones sobre los opcionales:

- **El INT del MAX30102 no hace falta.** El driver vacia la FIFO por sondeo. Se
  lee solo como senial de vida y aparece en el diagnostico. Podes dejarlo
  desconectado (`ppg.int_pin: null`).
- **El buzzer tiene que ser PASIVO.** Se maneja por PWM para poder cambiarle el
  tono, que es lo que hace el bip de latido cuando baja la saturacion. Uno
  activo suena solo con darle tension y a una sola frecuencia: no sirve. Si no
  pones buzzer, el sonido sale por la salida de audio del Pi.

**Alimenta el AD8232 con 3.3 V, no con 5 V.** Su salida esta centrada en
VCC/2, asi que con 5 V las puntas pueden superar lo que tolera la entrada del
ADS1115 alimentado a 3.3 V.

### Electrodos (derivacion II)

| Cable | Donde va |
|---|---|
| RA (rojo) | debajo de la clavicula derecha |
| LA (amarillo) | costilla inferior izquierda / cadera |
| RL (verde, referencia) | abdomen inferior derecho |

Electrodos nuevos y con gel. Los secos dan una linea de base que se va a
cualquier lado y el detector de QRS se vuelve loco.

---

## Instalacion en el Pi

Raspberry Pi OS Bookworm o mas nuevo:

```bash
sudo raspi-config nonint do_i2c 0     # habilita I2C
sudo apt install -y python3-pygame python3-smbus i2c-tools
```

Subir el bus I2C a 400 kHz (viene a 100 kHz, que es lento para leer el ECG a
250 Hz). Agregar a `/boot/firmware/config.txt`:

```
dtparam=i2c_arm=on,i2c_arm_baudrate=400000
```

Reiniciar y verificar que aparezcan los dos chips:

```bash
i2cdetect -y 1
```

Tienen que salir `48` y `57`. Si falta alguno, revisa cableado y alimentacion
antes de seguir.

Dependencias de Python (Bookworm no deja instalar con pip en el sistema, asi
que va un entorno virtual):

```bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## Uso

```bash
python main.py                                    # pantalla completa, con hardware
python main.py --broker 192.168.0.50               # apuntando al broker
python main.py --no-backend                       # solo pantalla
python main.py --demo --windowed                  # sin sensores
python main.py --notch 60                         # zona de 60 Hz
python main.py --captura pantalla.png             # guarda una imagen y sale
```

### Teclas

| Tecla | Que hace |
|---|---|
| `X` | **arranca una medicion** (o la cancela si esta corriendo) |
| `ESC` / `Q` | salir |
| `M` | silenciar alarmas 2 minutos |
| `S` | sonido on/off |
| `1` `2` `3` | velocidad de barrido: 12.5 / 25 / 50 mm/s |
| `+` `-` | ganancia del ECG |
| `C` | limpiar las trazas |
| `D` | panel de debug |
| `F` | alternar pantalla completa |
| `F1`..`F6` | controles del modo demo |

---

## Medicion a demanda

**Modo opcional, no el default.** Se pide con `--a-demanda` o poniendo
`session.manual` en `true` en el JSON de configuracion. Sirve para revisar a
alguien que no esta monitorizado: una toma puntual, con su calentamiento y su
resumen.

En una cama de UCI **no se usa**: mientras nadie apriete la tecla, el equipo no
publica, y sin lecturas el backend no abre alertas ni la central ni la ronda
muestran nada.

Con este modo los sensores arrancan apagados y se despiertan con una tecla:

```
ESPERA  --X-->  ESTABILIZANDO (3 s)  -->  MIDIENDO (10 s)  -->  RESULTADO
   ^                                                               |
   +------------------------------- X -----------------------------+
```

![Pantalla de espera](docs/pantalla-espera.png)

![Resultado de la medicion](docs/pantalla-resultado.png)

Que pasa en cada fase:

| Fase | Modulos | Que se ve |
|---|---|---|
| **Espera** | MAX30102 en modo bajo consumo, ADS1115 en disparo unico | la tecla y el mensaje |
| **Estabilizando** | encendidos, alimentando los filtros | cartel de estabilizacion, sin trazas |
| **Midiendo** | encendidos y grabando | ondas, numeros y cuenta regresiva |
| **Resultado** | apagados otra vez | promedio, minimo y maximo de cada signo |

Con **`--sin-paneles`** las pantallas de espera y de resultado no aparecen: la
vista es siempre la misma y el estado se resume en un cartelito arriba, sin
tapar las ondas. Los numeros del panel quedan congelados en la ultima medicion.

### Por que hay una fase de estabilizacion

Los pasa-altos de 0.5 Hz del ECG y del pletismografo arrancan con un transitorio
que tapa la senial durante los primeros segundos. Si la ventana empezara en el
instante cero, esos segundos irian a la basura y los "10 segundos de medicion"
serian mentira. Con la espera previa, **los 10 segundos son 10 segundos utiles**:
lo que se dibuja en pantalla y lo que se manda al backend es exactamente la
ventana medida, ni una muestra mas.

### La respiracion no entra en 10 segundos

`RESP` va a decir **"sin dato en esta ventana"**, y no es un error. El filtro de
0.1 Hz necesita unos 12 segundos solo para asentarse, y despues hacen falta 3
ciclos respiratorios para tener un periodo confiable: en total 25 a 30
segundos. Con la ventana en 10 s no llega, y es preferible que lo diga a que
invente un numero.

Si queres el numero de respiracion, subi la ventana:

```bash
python main.py --duracion 40
```

La cuenta completa de por que hacen falta esos segundos esta en
[docs/respiracion.md](docs/respiracion.md).

### Ajustes

| Opcion | Que hace |
|---|---|
| `--duracion 30` | segundos de cada medicion |
| `--sin-paneles` | sin pantallas de espera ni de resultado: la vista queda siempre igual y la tecla solo controla cuando adquiere |
| `--a-demanda` | los sensores arrancan apagados y cada medicion la dispara la tecla |
| `--continuo` | mide siempre, sin tecla. **Ya es el default**; se mantiene por compatibilidad con los scripts que lo traen puesto |
| `--medir-al-inicio` | solo con `--a-demanda`: dispara la primera medicion al arrancar (util para un kiosco) |
| `session.key` | que tecla dispara (default `x`) |
| `session.warmup_s` | segundos de estabilizacion (default 3) |
| `session.result_hold_s` | segundos que queda el resultado; `0` = hasta que aprietes la tecla |
| `session.power_down_idle` | `false` deja los modulos encendidos entre mediciones |

Apagar los modulos entre mediciones no es solo consumo: el MAX30102 con los LED
encendidos se entibia, y un sensor caliente deriva.

Cada medicion terminada se manda al backend como un mensaje `measurement` con
el resumen completo. Es el mensaje mas comodo para armar historial: una fila
por medicion en vez de un caudal continuo.

---

## Configuracion

Todo esta en [config.py](config.py) con valores por defecto razonables. Para
cambiar algo sin tocar el codigo:

```bash
python main.py --save-config config.json   # genera el archivo con todo
nano config.json                           # editas lo que quieras
python main.py --config config.json
```

Tambien se puede por variables de entorno, util para el arranque automatico:

```bash
MONITOR_BROKER_HOST=192.168.0.50 MONITOR_DEVICE_ID=CAMA-3 python main.py
```

Lo que mas se suele tocar:

| Donde | Que |
|---|---|
| `backend.host` / `port` | broker MQTT (o `MQTT_HOST` en el `.env`) |
| `ecg.notch_hz` | 50 en Argentina/Europa, 60 en Norteamerica |
| `ecg.sample_rate_hz` | 250 por defecto. El ADS1115 llega a 860 |
| `ecg.frontend_gain` | ganancia del modulo AD8232 (tipico 1100) |
| `ecg.lead_label` | como se rotula la traza: `ECG`, `ECG II`, `DI`... |
| `resp.enabled` | `false` saca la estimacion de respiracion y su carril |
| `alarms.*` | limites de FC, SpO2 y respiracion |
| `ppg.led_red_current` / `led_ir_current` | subilos si el indice de perfusion queda muy bajo |
| `ui.sweep_seconds` | cuantos segundos entran a lo ancho |

---

## Que manda al backend

Va por **MQTT sobre TLS**, no por HTTP. El contrato completo esta en
**[JSON.md](JSON.md)**. Resumen:

- Tema `siappc/<device>/telemetry`, **una lectura suelta por mensaje**, QoS 1
- Cinco variables: `hr`, `spo2`, `pr`, `perfusion`, `resp`
- Cada lectura lleva un **hash SHA-256** que el backend usa para deduplicar
- Tema `siappc/<device>/status` retenido, con Last Will si el Pi desaparece
- Si se cae la red, encola en SQLite (hasta un dia) y reenvia al reconectar
- **Las ondas no se publican**: el backend guarda una fila por lectura y el ECG
  son 250 muestras por segundo. Se dibujan en pantalla y ahi se quedan

Configuracion del broker: copia `.env.example` a `.env` y ajusta. Dentro de
SIAPPC (en `iot/monitor/`) no hace falta: se lee `iot/.env`.

Para ver que sale la telemetria sin levantar el backend:

```bash
python tools/receptor_prueba.py --host 192.168.0.100
```

Se suscribe a los mismos temas que el backend y **valida cada payload con las
mismas reglas**, asi que avisa si algo se iba a rechazar.

---

## Arranque automatico

### Con escritorio (lo mas simple)

```bash
mkdir -p ~/.config/autostart
cp scripts/monitor.desktop ~/.config/autostart/
```

### Sin escritorio, directo a la consola

Va mas fluido porque no hay compositor en el medio. SDL dibuja sobre KMS/DRM:

```bash
sudo cp scripts/monitor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now monitor
journalctl -u monitor -f          # para ver que pasa
```

El usuario tiene que estar en los grupos `video`, `render`, `i2c` y `gpio`:

```bash
sudo usermod -aG video,render,i2c,gpio $USER
```

---

## Si algo no anda

### Primero: el diagnostico

Antes de tocar nada, corre esto. Prueba cada modulo por separado, no abre
ninguna ventana (asi que anda por SSH) y te dice exactamente que falla:

```bash
.venv/bin/python tools/diagnostico.py
```

Que revisa:

- escanea el bus I2C y confirma que esten el `0x48` y el `0x57`
- enciende el MAX30102, lee unos segundos y te muestra el DC del infrarrojo y
  del rojo, si hay dedo y si la senial pulsa
- lee el ADS1115 y verifica que la continua del AD8232 este cerca de VCC/2, que
  es la prueba de que el frente analogico esta bien alimentado
- **avisa si dos cosas quedaron asignadas al mismo GPIO**
- hace sonar el buzzer con cuatro tonos

Al final imprime una lista de los problemas encontrados y como arreglarlos.

### Despues: los sintomas sueltos

**No aparece nada en `i2cdetect`**
I2C deshabilitado, o SDA/SCL cruzados, o el modulo sin alimentacion. El
MAX30102 de las placas moradas a veces necesita resistencias de pull-up de 4.7k
a 3.3 V en SDA y SCL.

**`PART_ID inesperado: 0x11`**
Es un MAX30100, no un MAX30102. Los registros son distintos y este driver no
le sirve.

**Arranca pero no mide nada, y los LED del MAX30102 no se encienden**
En continuo —el default— esto NO es lo esperado y hay que revisar el sensor con
`tools/diagnostico.py`. Si el equipo quedo en modo a demanda (`--a-demanda` en
el `monitor.service`, o `session.manual: true` en el JSON), entonces si es lo
normal: apreta `X` para medir 10 segundos, o quita esa opcion para que mida sin
parar.

**Dice ELECTRODO SUELTO todo el tiempo, con el ECG plano**
Fijate que en `ecg.lo_plus_pin` y `ecg.lo_minus_pin` no haya un GPIO que tenga
otra cosa conectada. El programa lee ese pin en alto como electrodo despegado
y silencia el ECG, sin ninguna pista de por que. `tools/diagnostico.py` lo
detecta. Para descartarlo rapido, poné los dos en `null`.

**El ECG es una linea plana**
Casi siempre son los electrodos. Si en pantalla dice ELECTRODO SUELTO, LO+/LO-
estan en alto: revisa el contacto. Si no dice nada pero igual esta plano, abri
el panel de diagnostico con la tecla `D` y mira `base AD8232`: tiene que dar
cerca de **1.65 V** (la mitad de 3.3 V). Si da casi 0 o casi 3.3, el modulo
esta pegado a un riel o mal alimentado, y no es un problema de software.

**Dice SENIAL DE ECG SATURADA**
La salida del AD8232 esta chocando contra su alimentacion. Suele ser el
paciente moviendose, un electrodo despegandose, o el modulo alimentado a 5 V
en vez de 3.3 V. Mientras dure eso, lo que se dibuja no es el corazon.

**El ECG es una senoide de 50 Hz**
Ruido de red. Verifica que `ecg.notch_hz` coincida con tu pais, aleja los
cables del cargador del Pi y no toques la parte metalica de los electrodos.

**La FC no aparece nunca**
El detector necesita unos 4 segundos para asentarse y aprender el umbral. Si
despues de eso sigue en `---`, la senial esta muy ruidosa o muy chica.

**El SpO2 tarda o salta**
Necesita 3 latidos limpios (unos 6 segundos). El dedo tiene que estar apoyado
firme y quieto, sin apretar. Si el indice de perfusion queda por debajo de 0.2
subi `ppg.led_red_current` y `led_ir_current`.

**Va a pocos fps**
Baja `ui.fps` a 30, o `ecg.sample_rate_hz` a 128. Un Pi 4 con HDMI 1080p tiene
que ir a 60 sin despeinarse.

**`SIN SERVIDOR` en el pie**
El Pi no llega al broker. Las lecturas no se pierden: se acumulan en la cola
local y salen al reconectar. Revisa que `MQTT_HOST` apunte a la maquina del
Compose, que el puerto 8883 este abierto, y que el `ca.crt` sea el del broker.
Si el broker se alcanza por IP, esa IP tiene que estar en el certificado como
SAN o el Pi lo rechaza a proposito.

---

## Como esta organizado

```
config.py           toda la configuracion, en un solo lugar
iot_env.py          broker y credenciales (del entorno o de iot/.env)
main.py             arma todo y corre el bucle principal
state.py            la foto del estado que comparten UI, alarmas y red
alarms.py           limites, antirrebote, prioridades y silencio

sensors/
  max30102.py       driver I2C del pulsioximetro
  ecg_ads1115.py    driver del ADS1115 + deteccion de electrodo suelto
  simulator.py      seniales sinteticas para el modo demo
  acquisition.py    hilos que leen los sensores a ritmo constante

processing/
  filters.py        biquads (pasa-altos, pasa-bajos, notch) y buffers
  ecg.py            deteccion de onda R y frecuencia cardiaca
  ppg.py            SpO2, pulso, perfusion y respiracion

net/
  publisher.py      publicacion MQTT, con reintento y cola local
  buffer.py         cola en SQLite de lecturas sin confirmar

ui/
  monitor.py        pantalla: barrido de ondas, panel numerico, alarmas
  theme.py          colores, tipografias, grilla
  sound.py          bip de latido y tonos de alarma

sensors/buzzer.py     buzzer pasivo por PWM (esta aca porque es hardware)

tools/
  diagnostico.py      prueba cada modulo por separado, sin abrir ventana
  receptor_prueba.py  se suscribe al broker y valida lo que publica el Pi
```

El bucle principal es de un solo hilo: los sensores producen en hilos aparte y
la red consume en otro, pero **todo el procesamiento y el dibujado pasan por el
mismo hilo**. Por eso no hay locks en los filtros ni en los detectores.
