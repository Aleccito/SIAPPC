"""Configuracion central del monitor de signos vitales.

Todo lo que se toca sin abrir el resto del codigo vive aca. Se puede pisar con
un archivo JSON (--config mi_config.json) o con variables de entorno MONITOR_*.

Ejemplo de override por entorno:
    MONITOR_BROKER_HOST=192.168.0.50 python main.py

Lo del broker (host, usuario, contrasena, CA) NO vive aca: sale del entorno o de
un `.env` a traves de `iot_env.py`, para que la contrasena este en un solo sitio
y `--save-config` no la escriba en un JSON.
"""

from __future__ import annotations

import json
import os
import socket
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import Any

import iot_env


# --------------------------------------------------------------------------
# Hardware
# --------------------------------------------------------------------------


@dataclass
class EcgConfig:
    """AD8232 (salida analogica) leido por un ADS1115."""

    i2c_bus: int = 1
    ads_address: int = 0x48  # ADDR a GND. 0x49=VDD, 0x4A=SDA, 0x4B=SCL
    ads_channel: int = 0  # AIN0 <- OUTPUT del AD8232
    # SPS soportados por el ADS1115: 8,16,32,64,128,250,475,860.
    # 250 alcanza y sobra para ver morfologia; 475 si el Pi da el cuero.
    sample_rate_hz: int = 250
    # Ganancia del PGA en volts full-scale: 6.144, 4.096, 2.048, 1.024, 0.512, 0.256
    # El AD8232 saca ~0..3.3V centrado en VCC/2, asi que 4.096 es lo correcto.
    pga_volts: float = 4.096
    # Ganancia del AD8232 (fija en el modulo tipico ~ x1100 con el filtro de a bordo).
    # Solo se usa para convertir a mV. OJO: es la ganancia NOMINAL del diseno de
    # referencia, no una calibracion. Los mV que salen son aproximados.
    frontend_gain: float = 1100.0
    # Alimentacion del AD8232. Se usa para detectar cuando su salida pega
    # contra un riel (electrodo moviendose, mal contacto).
    supply_volts: float = 3.3
    # Como se rotula el trazo. Con 3 electrodos la derivacion depende de donde
    # los pegues, y el modulo no tiene forma de saberlo: por eso "ECG" a secas.
    # Si los ubicas en RA / pierna izquierda / RL, poné "ECG II".
    lead_label: str = "ECG"
    # Deteccion de electrodo suelto (LO+ / LO-). None = deshabilitado.
    # OJO: si aca hay un pin que en realidad tiene otra cosa conectada, el
    # programa lo lee como "electrodo despegado" y el ECG queda en linea plana
    # sin ninguna explicacion visible. Ante la duda, poné null en los dos.
    lo_plus_pin: int | None = 22   # pin fisico 15
    lo_minus_pin: int | None = 27  # pin fisico 13
    # Pin SDN del AD8232 (apagado por hardware). None = no cableado; en ese caso
    # el frente analogico queda encendido y solo se apaga el ADS1115.
    # En bajo apaga el modulo, en alto lo enciende.
    sdn_pin: int | None = None
    # Filtrado
    highpass_hz: float = 0.5
    lowpass_hz: float = 40.0
    notch_hz: float | None = 50.0  # 50 en Argentina/Europa, 60 en Norteamerica
    notch_q: float = 30.0


@dataclass
class PpgConfig:
    """MAX30102: pulsioximetro (LED rojo + infrarrojo)."""

    i2c_bus: int = 1
    address: int = 0x57
    # Config del chip. sample_rate/averaging dan la frecuencia efectiva de salida:
    #   fs_efectiva = sample_rate_hz / averaging
    sample_rate_hz: int = 400  # 50,100,200,400,800,1000,1600,3200
    averaging: int = 4  # 1,2,4,8,16,32  -> 400/4 = 100 Hz de salida
    pulse_width_us: int = 411  # 69,118,215,411 (411 = ADC de 18 bits)
    adc_range_na: int = 4096  # 2048,4096,8192,16384
    led_red_current: int = 0x24  # 0x00..0xFF (~0.2 mA por paso)
    led_ir_current: int = 0x24
    # Muchos modulos clones traen los LED al reves de lo que dice la hoja de
    # datos: lo que sale primero en la FIFO es el infrarrojo y no el rojo. Con
    # los canales cambiados la relacion R queda invertida y el SpO2 da
    # cualquier cosa. Como saberlo: con el dedo puesto, el DC del infrarrojo
    # tiene que ser MAYOR que el del rojo, porque el tejido absorbe mucho mas
    # el rojo. Si da al reves, poné esto en true.
    # tools/diagnostico.py lo detecta y avisa.
    swap_leds: bool = False
    # Pin INT del MAX30102. None = no cableado.
    # El driver NO lo necesita: vacia la FIFO por sondeo. Se lee solo como
    # senial de vida del sensor, y aparece en el diagnostico y en la tecla D.
    int_pin: int | None = 17  # pin fisico 11
    # Umbral de "hay dedo": DC del infrarrojo por debajo de esto = sensor al aire
    finger_threshold: int = 50_000
    # Filtrado del pulso
    highpass_hz: float = 0.5
    lowpass_hz: float = 5.0
    # Ventana para calcular SpO2 (segundos)
    spo2_window_s: float = 4.0
    read_interval_s: float = 0.02


@dataclass
class RespConfig:
    """Respiracion derivada de la modulacion del PPG (no es un sensor aparte)."""

    enabled: bool = True
    fs_hz: int = 25  # se decima desde el PPG
    highpass_hz: float = 0.1  # 6 rpm
    lowpass_hz: float = 0.7  # 42 rpm


# --------------------------------------------------------------------------
# Red / backend
# --------------------------------------------------------------------------


@dataclass
class BackendConfig:
    """Publicacion por MQTT hacia el backend de SIAPPC.

    Antes esto armaba un sobre `monitor.v1` y lo mandaba por HTTP a
    `POST /api/v1/ingest`. Ese endpoint no existe: la telemetria de SIAPPC entra
    por MQTT, en `siappc/<dispositivo>/telemetry`, y la consume
    `backend/src/services/mqttIngest.ts`. El contrato esta en JSON.md.

    Aca solo esta *que* se publica y *cada cuanto*. El host, el usuario, la
    contrasena y la CA del broker salen del entorno o de `iot/.env` (ver
    `iot_env.py`): asi hay un solo sitio donde vive la contrasena y
    `--save-config` no la escribe en un JSON.
    """

    enabled: bool = True
    # Por defecto lo que diga el entorno. Estan aca (y no solo en iot_env) para
    # poder apuntar el monitor a otro broker sin tocar el .env compartido.
    host: str = field(default_factory=lambda: iot_env.MQTT_HOST)
    port: int = field(default_factory=lambda: iot_env.MQTT_PORT)
    # Cada cuanto se publica una tanda de signos vitales. Son hasta 5 filas en
    # `lectura` por tanda (hr, spo2, pr, perfusion, resp).
    vitals_interval_s: float = field(default_factory=lambda: iot_env.PUBLISH_INTERVAL)
    # QoS 1: el broker confirma la entrega. Los duplicados que eso pueda generar
    # los descarta el backend por el hash de la lectura.
    qos: int = 1
    # Cola local en SQLite. Si el broker no esta, las lecturas se acumulan aca y
    # salen al reconectar.
    buffer_path: str = field(default_factory=iot_env.monitor_buffer_path)
    buffer_max_rows: int = field(default_factory=lambda: iot_env.BUFFER_MAX_ROWS)


@dataclass
class SessionConfig:
    """Como se dispara la medicion: siempre (continuo) o con una tecla (a demanda)."""

    # False = continuo: los sensores miden siempre, como un monitor de cabecera.
    # True  = a demanda: arrancan apagados y una tecla dispara una ventana.
    #
    # El default es CONTINUO y no a demanda, que es como venia esta version.
    #
    # El motivo no es de preferencia, es de para que sirve el equipo. Esto se
    # instala a pie de cama en una UCI: el backend abre alertas cuando una cifra
    # se sale de rango, la central de monitoreo y la ronda las pintan, y las
    # notificaciones salen de ahi. Con `manual = True` la Pi NO PUBLICA NADA
    # mientras nadie apriete una tecla, asi que un paciente desatendido —que es
    # justo el caso para el que existe el sistema— no genera ni una lectura ni
    # una alerta. La pantalla se veria bien y no habria nada detras.
    #
    # El modo a demanda no se quita porque tiene su uso: una toma puntual con
    # calentamiento, para revisar a alguien que no esta monitorizado. Se pide
    # con `--a-demanda` o poniendo `session.manual` en el JSON de configuracion.
    manual: bool = False
    key: str = "x"  # tecla que dispara la medicion
    # Segundos de lectura efectiva
    duration_s: float = 10.0
    # Los filtros pasa-altos necesitan asentarse antes de que las cuentas sirvan.
    # Sin esto, los primeros segundos de la ventana se van en el transitorio.
    warmup_s: float = 3.0
    # Cuanto queda el resumen en pantalla antes de volver a la espera.
    # 0 = para siempre, hasta que se apriete la tecla otra vez.
    result_hold_s: float = 0.0
    # True  = pantallas completas de espera y de resultado (tapan las ondas)
    # False = la pantalla se ve siempre igual y solo aparece un cartelito
    #         arriba con el estado. La tecla sigue mandando igual.
    show_overlays: bool = True
    # Apagar los sensores mientras no se mide (menos consumo y menos calor en
    # el MAX30102, que si queda encendido con el dedo puesto se entibia).
    power_down_idle: bool = True


@dataclass
class DeviceConfig:
    # Tiene que coincidir con `dispositivo.codigo` en la base de SIAPPC. Si el
    # backend no lo encuentra ahi descarta las lecturas, porque no sabe a que
    # hospital colgarlas. Sale de DEVICE_CODE, el mismo que usa `iot/src/`.
    device_id: str = field(default_factory=lambda: iot_env.DEVICE_CODE)
    patient_id: str = "ANON-001"
    patient_name: str = "PACIENTE DE PRUEBA"
    bed: str = "CAMA 1"


# --------------------------------------------------------------------------
# Alarmas
# --------------------------------------------------------------------------


@dataclass
class AlarmLimits:
    hr_low: float = 50
    hr_high: float = 120
    spo2_low: float = 90
    resp_low: float = 8
    resp_high: float = 30
    # Segundos que una condicion tiene que sostenerse para disparar la alarma
    debounce_s: float = 3.0
    # Cuanto dura el silencio cuando se aprieta M
    mute_duration_s: float = 120.0


# --------------------------------------------------------------------------
# Interfaz
# --------------------------------------------------------------------------


@dataclass
class UiConfig:
    fullscreen: bool = True
    # (0, 0) = usar la resolucion nativa del monitor HDMI
    window_size: tuple[int, int] = (0, 0)
    fps: int = 60
    hide_cursor: bool = True
    sweep_seconds: float = 5.0  # cuanto tiempo entra a lo ancho de la pantalla
    sound_enabled: bool = True
    beat_beep: bool = True  # el "bip" clasico en cada latido
    show_debug: bool = False
    # Buzzer PASIVO por PWM. None = sin buzzer, el sonido sale por el audio del Pi.
    # Un buzzer activo NO sirve aca: suena solo con darle tension y no se le
    # puede cambiar el tono, que es justo lo que hacemos con el bip de latido.
    buzzer_pin: int | None = 12  # pin fisico 32
    # Frecuencia central del buzzer. Los pasivos rinden mucho mas cerca de su
    # resonancia (tipico 2 a 4 kHz); si suena flojo, proba mover esto.
    buzzer_tone_hz: int = 2400
    # "auto" usa el buzzer si hay pin configurado, si no el audio del Pi.
    # Tambien: "audio", "buzzer", "ambos".
    sound_output: str = "auto"


@dataclass
class Config:
    device: DeviceConfig = field(default_factory=DeviceConfig)
    session: SessionConfig = field(default_factory=SessionConfig)
    ecg: EcgConfig = field(default_factory=EcgConfig)
    ppg: PpgConfig = field(default_factory=PpgConfig)
    resp: RespConfig = field(default_factory=RespConfig)
    backend: BackendConfig = field(default_factory=BackendConfig)
    alarms: AlarmLimits = field(default_factory=AlarmLimits)
    ui: UiConfig = field(default_factory=UiConfig)
    # Modo demo: sin hardware, seniales sinteticas. Sirve para probar en la PC.
    demo: bool = False

    # ---- utilidades -----------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def load(cls, path: str | None = None) -> "Config":
        cfg = cls()
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                _merge(cfg, json.load(fh))
        _apply_env(cfg)
        return cfg

    def save(self, path: str) -> None:
        data = self.to_dict()
        # `buffer_path` sale resuelto a una ruta absoluta de la maquina donde se
        # genero el archivo. Un config.json escrito en Windows llevaria un
        # `C:\...` a la Pi, asi que no se escribe: al cargarlo se vuelve a
        # calcular. Si alguien lo pone a mano, `_merge` lo respeta igual.
        data["backend"].pop("buffer_path", None)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)


def _merge(target: Any, data: dict[str, Any]) -> None:
    """Pisa recursivamente los campos de un dataclass con un dict."""
    valid = {f.name: f for f in fields(target)}
    for key, value in data.items():
        if key not in valid:
            continue
        current = getattr(target, key)
        if is_dataclass(current) and isinstance(value, dict):
            _merge(current, value)
        elif isinstance(current, tuple) and isinstance(value, list):
            setattr(target, key, tuple(value))
        else:
            setattr(target, key, value)


# Solo se exponen por entorno las cosas que uno cambia al desplegar.
_ENV_MAP = {
    "MONITOR_BROKER_HOST": ("backend", "host", str),
    "MONITOR_BROKER_PORT": ("backend", "port", int),
    "MONITOR_BACKEND_ENABLED": ("backend", "enabled", lambda v: v.lower() in ("1", "true", "si", "yes")),
    "MONITOR_DEVICE_ID": ("device", "device_id", str),
    "MONITOR_PATIENT": ("device", "patient_name", str),
    "MONITOR_FULLSCREEN": ("ui", "fullscreen", lambda v: v.lower() in ("1", "true", "si", "yes")),
    "MONITOR_NOTCH_HZ": ("ecg", "notch_hz", float),
}


def _apply_env(cfg: Config) -> None:
    for env_name, (section, attr, caster) in _ENV_MAP.items():
        raw = os.environ.get(env_name)
        if raw is None:
            continue
        try:
            setattr(getattr(cfg, section), attr, caster(raw))
        except (ValueError, TypeError):
            print(f"[config] valor invalido en {env_name}={raw!r}, se ignora")
