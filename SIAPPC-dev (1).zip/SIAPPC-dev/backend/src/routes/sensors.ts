import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { Prisma } from "../generated/prisma/client.ts";
import { prisma } from "../lib/prisma.ts";
import { cached, cacheKey } from "../lib/cache.ts";
import { parseOr400 } from "../lib/http.ts";
import { env } from "../env.ts";
import { alertSeverities, alertStatuses } from "../types.ts";
import type { AlertaRow, LecturaRow, SensorAlert, SensorReading } from "../types.ts";

function toReading(row: LecturaRow): SensorReading {
  return {
    id: String(row.lectura_id),
    device: row.codigo,
    variable: row.variable_medida,
    unit: row.unidad,
    value: Number(row.valor),
    at: new Date(row.fecha_hora).toISOString(),
  };
}

function toAlert(row: AlertaRow): SensorAlert {
  return {
    id: String(row.alerta_id),
    readingId: String(row.lectura_id),
    device: row.codigo,
    variable: row.variable_medida,
    unit: row.unidad,
    value: Number(row.valor),
    type: row.tipo,
    severity: row.severidad,
    message: row.mensaje,
    status: row.estado,
    at: new Date(row.fecha_hora).toISOString(),
    resolvedAt: row.fecha_resolucion ? new Date(row.fecha_resolucion).toISOString() : null,
  };
}

const querySchema = z.object({
  device: z.string().min(1).max(50).optional(),
  variable: z.string().min(1).max(60).optional(),
  limit: z.coerce.number().int().positive().max(500).default(100),
});

const alertsQuerySchema = querySchema.extend({
  severity: z.enum(alertSeverities).optional(),
  status: z.enum(alertStatuses).optional(),
});

function whereClause(conditions: Prisma.Sql[]): Prisma.Sql {
  return conditions.length ? Prisma.sql`WHERE ${Prisma.join(conditions, " AND ")}` : Prisma.empty;
}

// Lecturas y alertas que alimentan el tablero de sensores y los reportes del
// frontend; ambas se llenan desde la ingesta MQTT (services/mqttIngest.ts).
//
// Van por consulta cruda a propósito: son tres JOIN sobre las dos tablas que
// crecen sin techo —una lectura por segundo y por sensor— y el plan que sale
// del `LIMIT` sobre `ix_lectura_sensor_fecha` es el motivo de que la pantalla
// responda. Con el constructor de consultas el SQL final queda fuera de la
// vista, y aquí lo que se está afinando es exactamente ese SQL.
//
// Las dos van además por caché en Redis (lib/cache.ts) con TTL corto, porque el
// tablero las repite en cada refresco para todos los usuarios conectados.
//
// La clave de caché NO incluye al usuario porque estas consultas todavía no
// filtran por hospital ni por unidad: la respuesta es la misma para cualquiera
// que pase el `authenticate`. El día que se agregue ese filtro, el
// identificador correspondiente tiene que entrar en la clave, o un usuario
// terminaría leyendo la respuesta cacheada de otro hospital.
export default async function sensorsRoutes(app: FastifyInstance) {
  app.addHook("preHandler", app.authenticate);

  app.get("/sensors/readings", async (req) => {
    const { device, variable, limit } = parseOr400(querySchema, req.query);

    // Se construye desde los valores ya validados por zod (`limit` es número,
    // no la cadena que vino en la URL), así una query basura nunca crea clave.
    const key = cacheKey("readings", { device, variable, limit });

    return cached(key, env.sensorsCacheTtl, req.log, async () => {
      const conditions: Prisma.Sql[] = [];
      if (device) conditions.push(Prisma.sql`d.codigo = ${device}`);
      if (variable) conditions.push(Prisma.sql`s.variable_medida = ${variable}`);

      const rows = await prisma.$queryRaw<LecturaRow[]>`
        SELECT l.lectura_id, l.valor, l.fecha_hora, s.variable_medida, v.unidad, d.codigo
        FROM lectura l
        JOIN sensor s ON s.sensor_id = l.sensor_id
        JOIN variable v ON v.codigo = s.variable_medida
        JOIN dispositivo d ON d.dispositivo_id = s.dispositivo_id
        ${whereClause(conditions)}
        ORDER BY l.fecha_hora DESC
        LIMIT ${limit}
      `;
      return rows.map(toReading);
    });
  });

  app.get("/sensors/alerts", async (req) => {
    const { device, variable, severity, status, limit } = parseOr400(alertsQuerySchema, req.query);

    const key = cacheKey("alerts", { device, variable, severity, status, limit });

    return cached(key, env.sensorsCacheTtl, req.log, async () => {
      const conditions: Prisma.Sql[] = [];
      if (device) conditions.push(Prisma.sql`d.codigo = ${device}`);
      if (variable) conditions.push(Prisma.sql`s.variable_medida = ${variable}`);
      if (severity) conditions.push(Prisma.sql`a.severidad = ${severity}`);
      if (status) conditions.push(Prisma.sql`a.estado = ${status}`);

      // alerta.fecha_hora es DATETIME (segundos), así que un lote de alertas
      // del mismo segundo empataría: alerta_id desempata por orden de
      // inserción.
      const rows = await prisma.$queryRaw<AlertaRow[]>`
        SELECT a.alerta_id, a.lectura_id, a.tipo, a.severidad, a.mensaje, a.estado,
               a.fecha_hora, a.fecha_resolucion,
               l.valor, s.variable_medida, v.unidad, d.codigo
        FROM alerta a
        JOIN lectura l ON l.lectura_id = a.lectura_id
        JOIN sensor s ON s.sensor_id = l.sensor_id
        JOIN variable v ON v.codigo = s.variable_medida
        JOIN dispositivo d ON d.dispositivo_id = s.dispositivo_id
        ${whereClause(conditions)}
        ORDER BY a.fecha_hora DESC, a.alerta_id DESC
        LIMIT ${limit}
      `;
      return rows.map(toAlert);
    });
  });
}
